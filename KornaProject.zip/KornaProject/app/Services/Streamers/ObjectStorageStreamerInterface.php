<?php

namespace App\Services\Streamers;

interface ObjectStorageStreamerInterface extends StreamerInterface
{
}
