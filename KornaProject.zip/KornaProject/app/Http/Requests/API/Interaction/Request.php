<?php

namespace App\Http\Requests\API\Interaction;

use App\Http\Requests\API\Request as BaseRequest;

class Request extends BaseRequest
{
}
