<?php

namespace App\Http\Requests\API;

/**
 * @property string $pageToken
 */
class YouTubeSearchRequest extends Request
{
}
