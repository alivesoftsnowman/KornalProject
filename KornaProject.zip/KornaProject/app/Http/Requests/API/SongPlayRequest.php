<?php

namespace App\Http\Requests\API;

/**
 * @property float $time
 */
class SongPlayRequest extends Request
{
}
