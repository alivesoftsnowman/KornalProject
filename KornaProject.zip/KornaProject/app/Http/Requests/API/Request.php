<?php

namespace App\Http\Requests\API;

use App\Http\Requests\AbstractRequest;

class Request extends AbstractRequest
{
}
